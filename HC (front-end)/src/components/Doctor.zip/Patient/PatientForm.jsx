import React, { Component } from 'react';
import { Button, Form, Col } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';

export default function PatientForm(props){
  
  const handleSubmitClick = (e) => {
    props.history.push('/');  
    e.preventDefault();
    
    let object = {};
    let formData=new FormData(e.target);
    formData.forEach((value,key)=>{
        object[key] = value;
        
    }
    );
    console.log(object);
    let json = JSON.stringify(object); 
    console.log(json); 


    const config = {     
        headers: { 'content-type' : "application/json" }
    }

    axios.post('http://localhost:8080/bookmydoctorapp/patient/register', json,config).then((response)=>{
         console.log(response);
       })   
       .catch((error)=>{
         console.log(error);
      });
    }

  function hm(){
      props.history.push('/doctors')
  }
  
        return (
          <div className="container">
    <div className="h2">   <h2>Fill the form to book an appointment</h2></div>
    <Form onSubmit={handleSubmitClick} className="form">
     
     <Form.Row >
       <Form.Group as={Col} controlId="formGridEmail">
         <Form.Label>Name</Form.Label>
         <Form.Control type="text" name="patientName" placeholder="Enter your name" />
       </Form.Group>
   
       <Form.Group as={Col} controlId="formGridEmail">
       <Form.Label>Age</Form.Label>
       <Form.Control type="number" name="patientAge" placeholder="Enter your age" />
       </Form.Group>
     </Form.Row>

     <Form.Row>
       <Form.Group as={Col} controlId="formGridCity">
         <Form.Label>Gender</Form.Label>
         <Form.Control as="select" name="gender" defaultValue="Choose...">
         <option>Choose...</option>
           <option>Male</option>
           <option>Female</option>
         </Form.Control>
       </Form.Group>
     </Form.Row>
   
     <Form.Group controlId="formGridPhone">
       <Form.Label>Phone Number</Form.Label>
       <Form.Control type="phone" name="patinetPhoneNumber" placeholder="Enter your phone number" />
     </Form.Group>
   
     <Form.Group controlId="formGridAge">
       
       <Form.Label>Email Id</Form.Label>
       <Form.Control type="email" name="patinetEmailId" placeholder="Enter your email" />
     </Form.Group>

   
     <Form.Row>
       <Form.Group as={Col} controlId="formGridCity">
         <Form.Label>City</Form.Label>
         <Form.Control as="select" name="patinetPlace" defaultValue="Choose...">
         <option>Choose...</option>
           <option>Bangalore</option>
           <option>Mumbai</option>
           <option>Chennai</option>
           <option>Hyderabad</option>
         </Form.Control>
       </Form.Group>
     </Form.Row>
   
     <Button variant="primary" type="submit">
       Book Appointment
     </Button>{' '}
     <Button variant="primary" type="submit" className="btn" onClick={hm}>
       Cancel
     </Button>
   </Form>
</div>
        );
      
    }  