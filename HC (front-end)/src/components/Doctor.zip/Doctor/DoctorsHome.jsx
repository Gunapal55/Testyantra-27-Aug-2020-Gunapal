import React, { Component } from 'react';
import Button from 'react-bootstrap/Button'; 
import axios from 'axios';

class DoctorsHome extends Component {
    constructor(props) {
        super(props);
        this.state = {
            doctor: [],
            updateClick: false,
            click: false
        }

    }

    doc = () => {
        this.setState({ click: true })
        axios.get('http://localhost:8080/bookmydoctorapp/patient/doctors')
            .then((resp) => {
                console.log(resp.data);
                this.setState({ doctor: resp.data.data })
                console.log(this.state.doctor);
            });
    }   
    
//     update=()=>{
//        this.setState({click:true})
//        axios.post('http://localhost:8080/bookmydoctorapp/doctor/register', json,config)
//        .then((response)=>{
//             console.log(response);
//           })   
//           .catch((error)=>{
//             console.log(error);
//          });
//        }
        
// }
        


    myClick=()=>{
        this.props.history.push('/doctor-profile')
    }

    proUpdate=()=>{
        this.props.history.push('/edit-profile')
    }


    render() {

        return (
            <div>
                <h1>Welcome</h1> <p>
                </p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi iste deserunt magni, sunt neque possimus, iure temporibus id tenetur aliquam quae sed natus! Suscipit dolorem aliquam, voluptatem nostrum temporibus at.</p>
                <Button variant="primary" size="lg" className="mr-5" onClick={this.myClick} active>
                    Create Profile</Button>
                <Button variant="primary" size="lg" className="mr-5" onClick={this.proUpdate} active>
                    Update Profile</Button>
                <Button variant="primary" size="lg" className="mr-5" href="/feedback" active>
                    View Appointments</Button>
                <Button variant="primary" size="lg" className="mr-5" href="/" active>
                    Log Out</Button>
            </div>
        );
    }
}

export default DoctorsHome;