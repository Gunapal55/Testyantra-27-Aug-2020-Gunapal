import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import {Form, Col, Button, InputGroup} from 'react-bootstrap';
import { render } from '@testing-library/react';


class UpdateDoc extends Component {
    constructor(props) {
        super(props);
        this.state = {
            doctor: [],
            click: false
        }
    }

    update = (params) => {

        axios.put('http://localhost:8080/bookmydoctorapp/doctor/manage-profile')
            .then(res => {
                this.setState({
                    cat: res
                });
            })
            .catch((err) => {
                console.log(err);
            })

    }


    click=()=>{
        this.props.history.push('/doctors-home')
    }

render(){

return(

    <div className="container">
    <div className="h1"><h1>Update your profile</h1></div> 
     <Form className="form" onSubmit={this.update}>
     <Form.Group controlId="name">
       <Form.Label> Name</Form.Label>
       <Form.Control type="name" placeholder="Enter your name" name="doctorName" />
     </Form.Group>
     <Form.Group controlId="qualification">
       <Form.Label>Qualification</Form.Label>
       <Form.Control type="text" placeholder="Qualification" name="doctorQualification" />
     </Form.Group>
     <Form.Group controlId="specialisation">
       <Form.Label>Specialisation</Form.Label>
       <Form.Control type="text" placeholder="Specialisation" name="doctorSpeacilization" />
     </Form.Group>
     <Form.Group controlId="prcticing">
       <Form.Label>Practicing From</Form.Label>
       <Form.Control type="date" placeholder="Practicing From" name='praticefrom' />
     </Form.Group>
     <div className="btn">
     <Button type="submit" >Submit</Button>
     <Button type="submit" onClick={this.click}>Cancel</Button></div>
   </Form>
   </div>
)

}

}
export default UpdateDoc;