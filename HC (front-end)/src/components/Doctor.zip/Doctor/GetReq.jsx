import React from 'react';
import axios from 'axios';

export default class GetReq extends React.Component{

      state = {
        doctors: [],
      }
    
      componentDidMount() {
          
        axios.get(`http://localhost:8082/bookmydoctorapp/patient/doctors/`)
          .then(res => {
            console.log(res);
            const doctors = res.data;
            this.setState({doctors});
          })
      }
    
      render() {
        return (
          <ul>
            <h4>List of Doctos</h4>
        { this.state.doctors.map((doctors) => <li key={doctors.id}>Name is {doctors.name}, Doctor Speacilization-{doctors.speacilization}</li>)}
          </ul>
        )
      }
    }