import React from 'react';
import { Component } from 'react';
import Table from 'react-bootstrap/Table';
import axios from 'axios';
import login from '../Login/Login';
import './patient.css';
import Button from 'react-bootstrap/Button'

class ListOfDoctor extends Component {
    constructor(props) {
        super(props);
        this.state = {
            doctor: [],
            click: false
        }

    }

    doc = () => {
        this.setState({ click: true })
        axios.get('http://localhost:8080/bookmydoctorapp/patient/doctors')
            .then((resp) => {
                console.log(resp.data);
                this.setState({ doctor: resp.data.data })
                console.log(this.state.doctor);
            });
    }

    myClick=()=>{
        this.props.history.push('/addPatient')
    }

    feed=()=>{
        this.props.history.push('/feedback')
    }


    render() {
        <login click={this.doc} />
        return (
            <div >
                <div className="h2">
                    <h2>Instant appointment with doctors<strong> Guaranteed.</strong></h2></div>
                <p></p>
                <h3>View all the doctors in the city and book an appointment based on their specialisation</h3>
                <ul>
                    <li><h4>Best</h4> </li>

                    <li>Best </li>

                    <li>Best </li>


                </ul>

                <Button variant="primary" size="lg" className="mr-5" onClick={this.doc} active>
                    Find me the right doctor</Button>
                    <Button variant="primary" size="lg" className="mr-5" onClick={this.feed} active>
                    Give Feedback</Button>
                    <Button variant="primary" size="lg" className="mr-5" href="/" active>
                    Log Out</Button>
                {
                    this.state.doctor.map((doc) => (
                        <div className="container">
                        <Table striped bordered hover>
                            <thead>
                                <tr>
                                    <th>SL NO</th>
                                    <th>Doctor Name</th>
                                    <th>Specialization</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        {doc.doctorId}
                                    </td>
                                    <td>
                                        {doc.doctorName}
                                    </td>
                                    <td>
                                        {doc.doctorSpeacilization}
                                        <Button variant="success" onClick={this.myClick}>Book Appointment</Button>
                                    </td>

                                </tr>

                            </tbody>

                        </Table>
                        </div>
                    ))
                }
            </div>
        );
    }
}
export default ListOfDoctor;