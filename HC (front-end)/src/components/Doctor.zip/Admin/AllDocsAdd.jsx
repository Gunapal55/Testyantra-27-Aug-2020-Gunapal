import React from 'react';
import { Component } from 'react';
import Table from 'react-bootstrap/Table';
import axios from 'axios';
import login from '../Login/Login';
import './viewalldoc.css';
import Button from 'react-bootstrap/Button'

class AllDocsAdd extends Component {

    constructor(props) {
        super(props);
        this.state = {
            doctor: [],
            click: false
        }
    }

    doc = () => {
        this.setState({ click: true })
        axios.get('http://localhost:8080/bookmydoctorapp/patient/doctors')
            .then((resp) => {
                console.log(resp.data);
                this.setState({ doctor: resp.data.data })
                console.log(this.state.doctor);
            });
    }

    myClick=()=>{
        this.props.history.push('/addPatient')
    }

    feed=()=>{
        this.props.history.push('/feedback')
    }
    
    home=()=>{
        this.props.history.push('/admin-home')
    }


    render() {
        <login click={this.doc} />
        return (
            <div >

                <h2>List of all doctors in Health-Care</h2>
             <br/>
             <Button variant="primary" size="lg" className="mr-5" onClick={this.doc} active>
                   View All doctors</Button>
                   
             <Button variant="primary" size="lg" className="mr-5" onClick={this.home} active>
                   Home </Button>

                {
                    this.state.doctor.map((doc) => (
                        <div className="container">
                        <Table striped bordered hover>
                            <thead>
                                <tr>
                                    <th>SL NO</th>
                                    <th>Doctor Name</th>
                                    <th>Specialization</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        {doc.doctorId}
                                    </td>
                                    <td>
                                        {doc.doctorName}
                                    </td>
                                    <td>
                                        {doc.doctorSpeacilization}
                                        <Button variant="success" onClick={this.myClick}>Update</Button>
                                        <Button variant="danger" onClick={this.myClick}>Delete</Button>
                                   
                                    </td>
                                    {/* <td>
                                        <Button variant="success" onClick={this.myClick}>Delete</Button>
                                    </td> */}
                                </tr>

                            </tbody>

                        </Table>
                        </div>
                    ))
                }
            </div>
        );
    }
}
export default AllDocsAdd;